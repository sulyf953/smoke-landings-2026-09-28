# Weekly creative ritual

| Day | Block | Action |
|-----|-------|--------|
| Mon | 45m | Export → update scorecard → apply KILLs |
| Tue | 30m | Write 2 ITERATE hooks from swipe file |
| Wed | 60m | Produce / brief creatives; launch WATCH |
| Thu | 30m | Advantage+ checklist on KEEP seeds |
| Fri | 30m | Re-score WATCH → promote or kill |
| Sun | 20m | Fill next week planner; note hypotheses |

Never skip Monday kills. Zombie ads are a tax.
