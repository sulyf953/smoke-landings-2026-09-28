# Changelog

## 0.3.0 — Scout absorb
- Consensus 2×CPA/0-purchase kill + 72h HOLD + fatigue FLAG
- Auction/creative/LP diagnosis tree; feeder vs scale cadence; free dist 1-pager
- Contested multipliers footnoted; Scout feed copied to sources/
- Aligned 48h rules + decision tree to Scout defaults

## 0.2.0 — sellable depth
- 48h kill rules with numeric gates
- Decision tree + edge cases + math cheatsheet
- 3 worked scorecards (KILL / ITERATE / KEEP) + combined board + Monday composite
- Advantage+ checklist + battle cards
- Filled weekly planner sample + ritual
- Agency SOP, client one-pager, briefing template, onboarding script
- 20 hook angles with why-it-works

## 0.1.0 — stub structure
- Initial folders and placeholders
