# Changelog

## 0.2.0 — sellable depth
- 48h kill rules with numeric gates
- Decision tree + edge cases + math cheatsheet
- 3 worked scorecards (KILL / ITERATE / KEEP) + combined board + Monday composite
- Advantage+ checklist + battle cards
- Filled weekly planner sample + ritual
- Agency SOP, client one-pager, briefing template, onboarding script
- 20 hook angles with why-it-works

## 0.1.0 — stub structure
- Initial folders and placeholders
