# Advantage+ checklist (the arguments media buyers actually have)

Use before scaling KEEP creatives into Advantage+ Shopping / App / Sales / Leads campaigns.

## Creative diversity (non-negotiable)
- [ ] **≥3 creatives** that a human would call different (not crop variants)
- [ ] At least **2 formats** (e.g. UGC video + static, or demo + testimonial)
- [ ] Hooks differ in first 3 seconds / first line — same script ≠ diversity
- [ ] **Argument:** “Meta says 1 is enough to start.” **Counter:** early exploration with one creative = expensive false negatives; 3 seeds is cheap insurance

## Exclusions & overlapping auctions
- [ ] Existing customers excluded (or intentional upsell audience)
- [ ] Engagers 7–30d handled (exclude or dedicated retarget — pick one)
- [ ] No identical offer fighting in a duplicated ABO ad set you forgot to pause
- [ ] **Argument:** “Advantage+ handles exclusions.” **Counter:** It doesn’t read your CRM; upload exclusions or you pay to re-acquire

## Learning & edits
- [ ] No daily creative swaps on the same ad ID
- [ ] Budget changes ≤20–30% per step
- [ ] Pixel/CAPI events match optimisation (Lead vs Schedule vs Purchase)
- [ ] **Argument:** “I’ll just edit the headline.” **Counter:** Significant edits reset learning; duplicate instead

## Signal quality
- [ ] ≥50 optimisation events/week at campaign level when possible (or accept longer learning)
- [ ] Landing page matches hook (see kill rule on CVR mismatch)
- [ ] UTMs present for post-hoc creative scorecards outside Ads Manager

## Kill Sheet integration
- [ ] Every seed creative has a scorecard row
- [ ] No creative that failed 48h kill rules is left as a seed
- [ ] Weekly ritual scheduled (see planner)

## When Advantage+ underperforms
1. Check creative diversity first (usually this).
2. Check exclusions / audience pollution.
3. Check event match.
4. Only then blame the algorithm.
