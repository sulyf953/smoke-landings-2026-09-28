# Pre-flight (before scorecard day)
- [ ] Pixel / CAPI firing on correct event
- [ ] Offer URL live; mobile OK
- [ ] Brand safety / landing match hooks
- [ ] Target CPA written on scorecard header
- [ ] Account median CTR computed (14d, same objective)
