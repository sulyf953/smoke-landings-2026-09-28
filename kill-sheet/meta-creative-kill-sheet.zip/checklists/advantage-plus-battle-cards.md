# Advantage+ battle cards (buyer vs stakeholder)

## “Just turn on Advantage+ and let it learn”
**Counter:** Learning on weak seeds burns budget. Pass Kill Sheet + ≥3 diverse creatives first.

## “Exclusions hurt scale”
**Counter:** Re-acquiring customers looks like scale and destroys LTV. Exclude or segment intentionally.

## “We need 20 creatives in the ad set”
**Counter:** 20 near-duplicates is not diversity; it’s noise. 3–6 true variants beat 20 crops.

## “CBO/Advantage will move budget to winners anyway”
**Counter:** It can’t invent a hook. Your job is supply; its job is allocate.

## “Creative testing is separate from Advantage+”
**Counter:** Tuesday ITERATE hooks become Thursday seeds. One system.
