# Feeder vs Scale campaign cadence

## Weekly
- [ ] Feeder (~20% budget) has 2–4 new variants max
- [ ] Winners promoted to scale/ASC only after spend×CPA proof
- [ ] Losers removed **one at a time**, spaced 3–5 days
- [ ] Always add before remove when possible
- [ ] No dumping net-new into winning ASC every 3–4 days

## Grey zone card
If creative sits ~5–10× CAC: hold, +20% budget test, or iterate **concept** — not instant kill.

## Creative velocity
Stopping new concepts after one winner = fatigue tax. Concept > hook > format.
