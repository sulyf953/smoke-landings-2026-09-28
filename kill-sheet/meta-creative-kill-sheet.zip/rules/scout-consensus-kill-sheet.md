# Scout-consensus Kill Sheet (absorbed 2026-09-29)

**Source feed:** Opportunity Scout `meta-creative-kill-rules-2026-09-29.md` (r/FacebookAds operator clusters).  
**Product north star:** Meta Creative Kill Sheet. Dist sibling = Ads Waste Grader (Google), not competing brand.  
**Caveat:** Contested multipliers are footnoted — tune on the buyer’s own CPA. Not financial advice.

## Front page defaults (print these)

| Line | Default | Contested band (footnote) |
|------|---------|---------------------------|
| **HOLD** | Age **< 72h** → ignore ROAS/CPA/CVR | Some cold-pixel ops wait 5–7d |
| **KILL (0 purchases)** | Spend ≥ **2× target CPA** AND purchases = 0 | Aggressive 1.5× · Patient 3–4× |
| **KILL (with volume)** | Spend ≥ **2–3× CPA** with weak results after Gate 0 | One cluster: 2–3× with 20+ conv poorly |
| **FATIGUE FLAG** | Own-creative CTR ↓ **≥15–20%** vs 7d peak **AND** freq ≥ **2.5–3** + CPA rising | Abs freq 2.5 vs 3 vs 4; CTR drop 15 vs 20–30 |
| **CTR watch** | Outbound CTR **<~1%** (some <0.5% after volume) | **Watch only** — winners can convert at low CTR; do not auto-kill on CTR alone |
| **Grey zone** | ~**5–10× CAC** borderline | Hold / +20% / iterate concept — not binary kill |

## Diagnosis tree (before blaming creative) — CONSENSUS

```
CPM↑ + CTR flat/down  → AUCTION pressure — don’t touch creative first
CPM flat + CTR↓       → CREATIVE fatigue — kill/iterate hook
CTR good + no CV      → LANDING / OFFER — don’t kill creative yet
```

## Feeder / scale cadence — CONSENSUS

- Keep **~20% budget** in ABO/test feeder; do **not** dump new creatives into winning ASC every 3–4 days.
- Promote winners one at a time; retire losers **one at a time**, spaced **3–5 days**; add before remove.
- Concept > hook > format > pixel tweaks.
- Scale wall: if CTR stable but CVR↓ → audience expansion, **not** always kill creative. Stage **4–6 fresh concepts** before re-scale.

## Trained vs cold pixel (ASC/Advantage+)

| Pixel state | Early read | Kill patience |
|-------------|------------|---------------|
| Trained (100+ purchases class) | ~3d and £/$50–80/creative can be enough | Still HOLD first 48–72h noise |
| Cold | 5–7d minimum; first 48h noise | Prefer spend×CPA over calendar |

## How this maps to existing 48h rules

| Existing pack rule | Scout alignment |
|--------------------|-----------------|
| Gate 0 (impr/spend/time) | Keep — still blocks noise kills |
| CTR <0.60% kill | Downgrade to **WATCH** if spend×CPA not met; Scout says CTR alone ≠ kill |
| CPA >1.5× kill | Align default kill to **2× / 0 purchases**; keep 1.5× as aggressive slider |
| Freq >3.5 + CPA↑ | Align fatigue FLAG to CTR↓15–20% + freq 2.5–3 |
| ITERATE band | Matches grey zone / concept iterate |

**Operator rule ID for scorecard notes:** `SCOUT-HOLD-72`, `SCOUT-KILL-2x0`, `SCOUT-FATIGUE`, `SCOUT-DIAG-AUCTION|CREATIVE|LP`, `SCOUT-FEEDER`.
