# 48h kill rules — extended numeric playbook

Companion to `48h-kill-rules.md`. Same rule IDs; more numbers and worked thresholds.

## Gate 0 — eligibility (must pass before kill logic)
| Objective | Min impressions | Min spend (GBP/USD approx) | Notes |
|-----------|-----------------|----------------------------|-------|
| Prospecting Feed/Reels | 3,000 | £/$20 | Don’t kill on noise |
| Remarketing | 2,000 | £/$15 | Frequency matters more |
| Advantage+ shopping | 5,000 | £/$30 | Creative reporting laggy |

If Gate 0 fails → **WATCH**, never KILL.

## Rule 48h-#1 — CTR floor (prospecting)
Kill when CTR < **0.60%** (Feed) or < **0.45%** (Reels/Stories) after Gate 0, **and** CTR is below account median × 0.7.

Worked: median 1.1%, creative 0.55% Feed → 0.55 < 0.77 (0.7×median) and < 0.60 → KILL.

## Rule 48h-#2 — CPA blowout
Kill when CPA ≥ **2.0×** target after ≥1 conversion **or** spend ≥ **1.5×** target with **0** conversions.

Worked: target £40, spend £72, 0 conv → KILL.  
Worked: target £40, CPA £95 after 2 conv → KILL.

## Rule 48h-#3 — CPC / CTR mismatch
If CPC > **1.8×** account median CPC **and** CTR < median → creative is expensive and weak → KILL or ITERATE (ITERATE only if hook was never tested; else KILL).

## Rule 48h-#4 — Frequency tax (remarketing)
Kill/remarket pause if frequency > **4.0** over 7d **and** CPA +**25%** vs prior 7d with no offer change.

## Rule 48h-#5 — Format loser
Same hook in static vs video: if one format CTR < **0.5×** the other after Gate 0 on both → pause the loser; keep the winner.

## ITERATE band (not kill)
- CTR within 0.7–1.0× median **and** CPA 1.2–1.9× target → rewrite first 3s / headline, keep offer.
- Max **two** iterate cycles; third miss → KILL.

## KEEP / scale band
- CTR ≥ median **and** CPA ≤ target → KEEP.
- CPA ≤ 0.85× target for 5+ days → seed Advantage+ (+ checklist).

## Daily residual waste estimate
`(sum of KILL-row daily spend)` ≈ money freed. Track for 2 weeks; this is the pack’s ROI story.
