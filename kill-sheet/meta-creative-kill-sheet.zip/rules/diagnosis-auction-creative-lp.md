# Diagnosis tree — auction vs creative vs offer/LP

Print on scorecard page 1. Source: Scout consensus (r/FacebookAds diagnosis threads).

## Branch 1 — Auction
**Signals:** CPM rising; CTR flat or only mildly down; CPC up; narrow audience + freq still low.  
**Action:** Widen / refresh audience, check placements, don’t kill creative. If freq <2 and CPM jumped → audience too narrow.

## Branch 2 — Creative fatigue
**Signals:** CPM flat; CTR dropping vs own baseline (≥15–20%); freq ≥2.5–3; CPA rising over several days.  
**Action:** KILL or ITERATE hook (first 3s / headline). Optional: thumbstop / 3s view ↓ precedes CTR death.

## Branch 3 — Offer / landing
**Signals:** CTR good (≥ median); clicks flow; CPA / CVR bad.  
**Action:** Fix LP/offer/checkout; do **not** pause a creative that is doing its job. Re-test after LP fix.

## Scale dip exception
CTR stable + CVR↓ after budget jump (e.g. past easy pocket) → marginal traffic, not creative death. Add 4–6 concepts before blaming the winner.
