# Edge cases & disputed calls

## Brand campaigns
Brand search-like Meta (remarketing engagers) often has high CTR and low CPA. **Do not** apply prospecting CTR floors blindly. Use frequency + CPA trend instead. Kill if frequency >4 and CPA +25% over 5 days with no offer change.

## Advantage+ “black box” delivery
You may not get clean creative-level learning. Still score whatever breakdown Ads Manager gives; if creative reporting is broken, score at ad-set proxies weekly and demand ≥3 seeds.

## Soft KPIs (thumbstop, holds)
If CAPI is broken, do **not** invent CPA. Fix measurement first (pre-flight). Soft KPIs alone never KEEP.

## Low-spend accounts (<£/$50/day)
Gate 0 may take >48h. Extend WATCH to **72–96h** but still kill on CTR <0.4% after 2k impressions — extreme dogs die early.

## Ascension / webinar funnels
CTR can be high with bad show-up. Add a **secondary kill:** cost per qualified sit >1.5× target even if CPL looks fine.

## UGC sacred cows
Founder favourite UGC dies under the same rules. Show the scorecard row; don’t debate taste.

## Seasonality
HVAC heatwave weeks: raise target CPA temporarily in writing; don’t silently loosen kill rules.
