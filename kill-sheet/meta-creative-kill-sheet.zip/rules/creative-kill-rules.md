# Creative kill / keep / iterate rules

**KILL** if after ≥3k impressions or £/$50 spend:
- CTR < 0.6% (feed) vs account median
- CPA > 1.5× target (learning-limited aside)
- Frequency > 3.5 with CPA rising 3 days

**ITERATE** if CTR OK but CPA soft — new hook, same offer.
**KEEP / SCALE** if CPA ≤ target and CTR ≥ median for 5+ days.

Never judge on <500 impressions.
