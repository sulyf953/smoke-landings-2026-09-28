# Decision tree

```
Spend ≥ £/$50 OR impr ≥ 3k OR 48h live?
 ├─ NO → WATCH
 └─ YES
     ├─ CTR < 0.60% AND < 50% median? → KILL
     ├─ CPA > 1.5× target (≥15 clicks or ≥£/$50)? → KILL
     ├─ Freq > 3.5 AND CPA rising 3d? → KILL
     ├─ CTR OK, CPA 1.0–1.5×? → ITERATE (new hook)
     ├─ CPA ≤ target 5d + CTR ≥ median? → KEEP/SCALE
     └─ Else → WATCH 24h then re-score
```

Document the rule number you used in the scorecard `notes` column.
