# Decision tree (Scout-aligned)

```
Age < 72h AND spend < 2× CPA?
 ├─ YES → HOLD on ROAS/CPA (may WATCH CTR dogs)
 └─ NO / Gate 0 passed
     ├─ Diagnose first:
     │    CPM↑ + CTR flat/↓ → AUCTION (don’t kill creative)
     │    CPM flat + CTR↓ → CREATIVE path ↓
     │    CTR good + no CV → LP/OFFER (don’t kill creative)
     ├─ Spend ≥ 2× target CPA AND results = 0? → KILL
     ├─ Fatigue: CTR↓≥15–20% vs own peak AND freq≥2.5–3 AND CPA↑? → KILL/ITERATE
     ├─ CTR watch <~1% but spend×CPA OK? → WATCH (not auto-kill)
     ├─ CPA 1.2–1.9× or grey 5–10× CAC? → ITERATE / hold
     ├─ CPA ≤ target 5d + CTR ≥ median? → KEEP/SCALE (feeder promote)
     └─ Else → WATCH 24h then re-score
```

Document rule IDs in scorecard `notes`: `SCOUT-HOLD-72`, `SCOUT-KILL-2x0`, `SCOUT-FATIGUE`, `SCOUT-DIAG-*`, `SCOUT-FEEDER`.
