# 48-hour kill rules (numbers, not vibes)

Use account currency. Defaults below assume **lead-gen or purchase** campaigns. Adjust the CPA target column to your real target before judging.

## Gate 0 — Don’t judge yet
| Metric | Minimum before a KILL/KEEP call |
|--------|----------------------------------|
| Impressions | **3,000** (feed) / **1,500** (stories/reels if spend-paced) |
| Spend | **£/$50** on that creative |
| OR time in learning | **48 hours** live with delivery |

If below Gate 0 → status **WATCH**, not KILL.

## Primary kill triggers (any ONE = KILL after Gate 0)
1. **CTR (link) < 0.60%** on Feed/Advantage+ and **< 50% of account median CTR** for same objective last 14d.
2. **CPA > 1.5× target** for ≥48h with ≥15 clicks (or ≥£/$50 spend).
3. **Frequency > 3.5** AND CPA up **>20%** day-over-day for 3 straight days.
4. **Thumbstop / hold rate** (if you have video avg play): **< 25%** of 3-second views vs your top quartile creative — and CTR also below median.
5. **Hook failure:** Outbound CTR OK but landing CVR < 50% of account median for 48h → creative may still die if message mismatch is creative-led (see ITERATE first).

## Iterate (not kill) — replace hook, keep offer
- CTR ≥ median, CPA between **1.0×–1.5×** target
- OR frequency 2.5–3.5 with soft CPA — new first 3 seconds / new headline
- OR static beating video (or vice versa) by >30% CTR — ship 2 variants of the winner format

## Keep / scale
- CPA **≤ target** for 5+ consecutive days
- CTR ≥ account median
- Frequency **≤ 2.8** (or stable CPA despite higher freq)
- At least one social proof or offer clarity element intact

## 48h sprint protocol
**Hour 0:** Export → scorecard.  
**Hour 2:** Apply kills (pause).  
**Hour 4:** Queue 2 ITERATE hooks from swipe file.  
**Hour 24:** Recheck WATCH rows that crossed Gate 0.  
**Hour 48:** Final KILL pass; move KEEP into scale budget (+20–30% only).

## Hard bans (buyer discipline)
- No “give it another week” under Gate 0 failures that already cleared Gate 0.
- No scaling a creative that fails rule 1 or 2.
- No resetting learning daily by editing the same ad.
