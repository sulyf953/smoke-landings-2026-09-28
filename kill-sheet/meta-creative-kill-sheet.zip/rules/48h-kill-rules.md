# 48-hour / spend-gate kill rules (numbers, not vibes)

Absorbed Scout consensus 2026-09-29. Use account currency. Set **target CPA** before judging.  
**Unit of kill = spend vs target CPA, not calendar days alone.**

## Gate 0 — Don’t judge yet
| Metric | Minimum before a KILL call |
|--------|----------------------------|
| Impressions | **3,000** Feed / **1,500** Stories-Reels if paced |
| Spend | **£/$50** on that creative **or** age with delivery |
| Early window | **HOLD < 72h** on ROAS/CPA/CVR (Scout consensus) — still allow extreme CTR dogs after Gate 0 impr as WATCH→soft pause only |

If below Gate 0 → **WATCH**, not KILL.

## Primary KILL (after Gate 0 / past HOLD)
1. **Spend ≥ 2× target CPA AND purchases/results = 0** → KILL.  
   *Slider:* 1.5× aggressive · 3–4× patient / high-AOV. Tag `SCOUT-KILL-2x0`.
2. **Spend ≥ 2–3× target CPA** with results but CPA staying ≥2× after meaningful volume → KILL or hard ITERATE.
3. **Fatigue fingerprint:** CTR ↓ ≥15–20% vs own 7d peak **AND** frequency ≥ **2.5–3** **AND** CPA rising over several days → KILL/ITERATE. Tag `SCOUT-FATIGUE`.
4. **Frequency tax (remarketing):** freq >4 AND CPA +25% over 5–7d with no offer change → pause.
5. **Format loser:** same hook, one format CTR <0.5× the other after Gate 0 on both → pause loser.

## WATCH (not auto-kill)
- Outbound CTR **<~1%** (or <0.5% after volume) → weak hook **watchlist**. Winners can convert at low CTR — **CTR alone ≠ kill** (Scout contested).
- Age <72h even if spend climbing — HOLD CPA judgment.

## ITERATE (not kill)
- CTR within ~0.7–1.0× median and CPA 1.2–1.9× target → new first 3s / headline.
- Grey zone ~5–10× CAC → hold / +20% / new concept — not binary kill.
- Max two iterate cycles; third miss → KILL.

## KEEP / scale
- CPA ≤ target for 5+ days and CTR ≥ median → KEEP.
- CPA ≤ 0.85× target → Advantage+ seed (pass checklist).
- Scale dip with **CTR stable + CVR↓** → audience expansion; stage 4–6 fresh concepts before killing the winner.

## 48–72h sprint protocol
**Hour 0:** Export → scorecard. Apply diagnosis tree first.  
**Hour 2:** Pause `SCOUT-KILL-2x0` / fatigue kills.  
**Hour 4:** Queue 2 feeder ITERATE hooks (not into winning ASC).  
**Hour 24–72:** Recheck WATCH; HOLD CPA until 72h unless 2×/0 already hit with volume.  
**Day 5–7:** Cold pixel final pass; promote feeder winners one at a time.

## Hard bans
- No judging ROAS in first 72h (except clear 2×/0 after Gate 0 spend).
- No dumping new creatives into winning ASC every 3–4 days.
- No resetting learning by editing the same ad daily.
- No killing on scale dip alone when CTR is stable.
