# Math cheatsheet

**CTR %** = clicks / impressions × 100  
**CPC** = spend / clicks  
**CPA** = spend / results (use Ads Manager’s result definition you optimise for)  
**× target** = CPA / target_CPA  
**Median CTR** = median of creative-level CTRs (same objective, 14d), not account average (averages hide dogs)

### Example
Spend £78.40, clicks 41, impr 12,400, results 1, target £35  
CTR = 41/12400 = 0.33%  
CPA = 78.40/1 = £78.40  
× target = 78.40/35 = 2.24 → kill band

### Batch kill impact
If three creatives waste £40/day combined, pausing frees £280/week — often more than a new test budget.
