# Math cheatsheet — formulas used in kill decisions

**Purpose:** Every KEEP / KILL / ITERATE call in this pack rests on one of these formulas.  
**Labeling:** Formulas themselves are **Evidence** (standard media-math). Thresholds you apply them against are **Inference** calibrated to *your* Target CPA/ROAS — never invent a universal £ kill price.

Use account currency throughout. Round to 2 decimals for CPA/CPC; 2 decimals for CTR %; 1 decimal for frequency and ×-target.

---

## Core formulas

| Name | Formula | Used for |
|------|---------|----------|
| **CTR %** | `(link_clicks / impressions) × 100` | Hook strength; Rule 48h-#1 |
| **Outbound CTR %** | `(outbound_clicks / impressions) × 100` | Prefer over “all clicks” when available |
| **CPC** | `spend / link_clicks` | Cost of attention; Rule 48h-#3 |
| **CPM** | `(spend / impressions) × 1000` | Auction pressure diagnosis |
| **CPA / CPL** | `spend / results` | Primary kill unit (results = purchases or leads) |
| **× target** | `CPA / target_CPA` | Capital-exposure gates (K1/K2) |
| **ROAS** | `purchase_value / spend` | ROAS-led accounts (flip of CPA) |
| **Frequency** | `impressions / reach` | Fatigue fingerprint |
| **CVR (click→result)** | `results / link_clicks` | Hook-OK / convert-fail diagnosis |
| **Hook rate (video)** | `3s_views / impressions` (or Meta “ThruPlay starts”) | Early creative death signal |
| **Median CTR** | median of creative-level CTRs, **same objective, 14d** | Relative floors — never use account *average* (dogs hide in averages) |

---

## Worked kill math (Halal HVAC lead-gen)

| Input | Value |
|-------|-------|
| Spend | £78.40 |
| Link clicks | 41 |
| Impressions | 12,400 |
| Reach | 5,100 |
| Results (leads) | 1 |
| Target CPA | £35 |
| Account median CTR | 0.95% |

| Calc | Result | Decision implication |
|------|--------|----------------------|
| CTR | 41/12400 = **0.33%** | < 0.60% floor **and** < 50% of median (0.475%) → Rule 48h-#1 KILL |
| CPC | 78.40/41 = **£1.91** | Expensive attention |
| CPA | 78.40/1 = **£78.40** | × target = 78.40/35 = **2.24×** → Rule 48h-#2 KILL |
| Frequency | 12400/5100 = **2.43** | Not the kill reason here; CTR/CPA already fire |

---

## Worked iterate math (Halal tutoring)

| Input | Value |
|-------|-------|
| Spend | £207 |
| Results | 5 |
| Target CPA | £38 |
| CTR | 0.88% |
| Median CTR | 0.94% |
| Frequency | 2.9 |

| Calc | Result | Decision implication |
|------|--------|----------------------|
| CPA | 207/5 = **£41.40** | × target = 41.40/38 = **1.09×** — inside ITERATE band (1.0–1.5×), no hard kill |
| CTR vs median | 0.88 / 0.94 = **0.94×** | Hook still alive → rewrite first line, don’t kill concept |

---

## Worked keep math (Halal B2B lead-gen)

| Input | Value |
|-------|-------|
| Spend | £456 |
| Results | 16 |
| Target CPA | £40 |
| CTR | 1.19% |
| Median CTR | 0.95% |
| Frequency | 1.9 |
| Days on target | 6 |

| Calc | Result | Decision implication |
|------|--------|----------------------|
| CPA | 456/16 = **£28.50** | × target = **0.71×** → KEEP / scale candidate |
| CTR vs median | 1.19/0.95 = **1.25×** | Above median → seed Advantage+ with ≥2 siblings |

---

## Capital-exposure gates (spend vs CPA — not days)

**Evidence (operator consensus):** pause after meaningful spend vs *your* target, not “it’s been live 2 days.”  
**Inference (pack default):** print **2×** as default; footnote aggressive **1.5×** and patient **3–4×**.

| Gate | Condition | Action |
|------|-----------|--------|
| **K1 — Zero-result bleed** | `spend ≥ 2 × target_CPA` **AND** `results = 0` | KILL / PAUSE |
| **K2 — Extreme exposure** | `spend ≥ 5 × target_CPA` **AND** (`CPA > 2 × target` OR `ROAS < 0.5 × floor`) | KILL even if a few results dribbled |
| **Aggressive footnote** | swap 2× → 1.5× for trained pixel / high daily spend | Document on sheet header |
| **Patient footnote** | swap 2× → 3–4× for high-AOV / cold pixel | Document on sheet header |

**Do not** invent a universal £ kill price. Always: `N × YOUR target`.

---

## Fatigue fingerprint math

**Evidence:** CTR↓ + frequency↑ + CPA↑ over several days = fatigue; frequency alone is lagging.  
**Inference (pack defaults):** flag when **both** relative CTR drop and freq threshold fire.

| Signal | Formula / check | Pack default |
|--------|-----------------|--------------|
| Relative CTR drop | `(peak_7d_CTR − current_CTR) / peak_7d_CTR` | ≥ **15–20%** drop |
| Frequency warning (cold prospecting) | `impressions / reach` | ≥ **2.5–3.0** |
| CPA worsening | `(CPA_last_3d − CPA_prior_3d) / CPA_prior_3d` | ≥ **+20%** |
| Combined FLAG | CTR drop **AND** freq gate **AND** CPA rising | Fatigue → replace creative (prefer KILL+replace over endless edit) |

**Contested (do not hardcode as single truth):** absolute freq 2.5 vs 3 vs 4; CTR% drop 15 vs 20–30. Write *your* chosen band on the sheet header.

---

## Diagnosis math (auction vs creative vs offer/LP)

| Pattern | Math read | Blame |
|---------|-----------|-------|
| CPM↑ + CTR flat/down | CPM up ≥15% WoW, CTR not improving | **Auction** — don’t touch creative |
| CPM flat + CTR↓ | CTR down ≥15% vs own peak, CPM stable | **Creative fatigue** |
| CTR good + CVR↓ / 0 results | CTR ≥ median, `results/clicks` soft or zero | **LP / offer / tracking** |
| CTR stable + CVR↓ after scale | Budget up, CTR holds, CPA rises | **Audience expansion / scale wall** — not auto-kill creative |

---

## Batch waste freed (ROI story for the pack)

```
daily_waste_freed ≈ sum(daily_spend of rows marked KILL)
weekly_waste_freed ≈ daily_waste_freed × 7
```

**Example:** three KILL rows averaging £40/day combined → **£280/week** freed — often enough to fund the next ITERATE batch. Track for 2 weeks; this is the buyer’s before/after screenshot.

---

## ROAS ↔ CPA conversion (when finance speaks ROAS)

If AOV (average order value) is known:

```
target_CPA ≈ AOV / target_ROAS
implied_ROAS ≈ AOV / CPA
```

**Example (Halal ecom):** AOV £48, target ROAS 2.0× → target CPA ≈ £24.  
If a creative’s CPA is £52 → implied ROAS ≈ 48/52 = **0.92×** → under floor → kill band.

**Do not invent AOV or competitor prices.** Pull AOV from the buyer’s own store analytics.

---

## Blast-radius math

```
max_kills_this_session = floor(0.20 × active_creatives_count)
```

If you need more kills, queue replacements first (**Evidence-aligned** blast-radius discipline from public triage templates). Exception: K5 compliance / broken URL — kill immediately regardless of cap.

---

## Quick reference card (print)

1. Gate 0 cleared? (`spend ≥ £/$50` OR `impr ≥ 3k` OR 48h delivery)  
2. `× target = CPA / target_CPA`  
3. `CTR%` vs median and vs 0.60% Feed floor  
4. Fatigue: relative CTR drop + freq ≥ 2.5–3  
5. Diagnosis: CPM / CTR / CVR pattern before creative blame  
6. Blast radius ≤ 20% unless replacements live  

*Operator checklist, not Meta platform advice. Calibrate multiples to your Target CPA before printing as guarantees.*
