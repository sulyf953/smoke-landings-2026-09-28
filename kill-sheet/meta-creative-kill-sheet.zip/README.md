# Meta Creative Kill Sheet — Sellable v0.2

**Product north star** (CEO binding lock 2026-09-29). For Meta (Facebook/Instagram) Ads operators and agencies who need a ruthless, numbers-backed way to kill weak creatives in **48 hours**, keep winners, and plan the next batch.

**Distribution funnel (separate):** Ads Waste Grader → £79 Fix Pack unlock (`../ads-waste-interceptor/`). Grader is dist, not a competing product.

## Who buys this
- Media buyers / performance marketers running Meta weekly
- Small agencies managing 3–30 ad accounts
- Founders who are their own media buyer and keep “zombie” ads alive too long

## What you get
| Path | What it is |
|------|------------|
| `rules/48h-kill-rules.md` | Numeric kill / keep / iterate rules with thresholds |
| `rules/decision-tree.md` | If/then tree from spend → decision |
| `scorecard/` | Blank + **3 worked examples** (KILL / ITERATE / KEEP) |
| `checklists/advantage-plus-checklist.md` | Advantage+ items media buyers actually argue about |
| `planner/` | Weekly ritual + **filled** sample week |
| `swipe/hook-angles.md` | 20 halal-safe angles with why they work |
| `worked-examples/` | Narrative walkthroughs matching the scorecards |

## How to use (30 min first time)
1. Export Ads Manager rows for creatives with ≥£/$50 spend or ≥3k impressions in last 7 days.
2. Fill `scorecard/creative-scorecard.csv`.
3. Apply `rules/48h-kill-rules.md` — no vibes.
4. Run Advantage+ checklist before you scale survivors.
5. Fill next week’s planner from kills + hook swipe.

## Price band
$49–$99 pack · Fix Pack upsell via grader funnel (£79)

## Halal
Efficiency tooling only. Examples use home services, tutoring, B2B SaaS — no gambling, alcohol, adult, interest products.

## Not included
Ads Manager login, auto-pause API, creative production, media buying services.
