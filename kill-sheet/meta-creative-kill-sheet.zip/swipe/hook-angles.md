# Hook angles (20, halal-safe) — with “why it works”

1. **Seasonal deadline** — “Before the first heatwave” — urgency without fake scarcity.
2. **Cost of waiting** — “Emergency call-out vs tune-up” — loss framing on real costs.
3. **Time saved** — “Get 4 hours back this week” — B2B classic.
4. **Predicted outcome** — “Grade band in 6 weeks” — concrete tutoring promise.
5. **Myth bust** — “You don’t need a full system replace” — pattern interrupt.
6. **Neighbor proof** — “38 jobs in [area] this month” — local trust.
7. **Checklist magnet** — “Free 12-point inspection list” — low friction lead.
8. **Before/after ops** — Desk chaos → clean dashboard — visual story.
9. **Objection crush** — “No long contract” — upfront risk removal.
10. **Founder face** — Authority without celebrity.
11. **Number lead** — “£35 tune-up” in first line — clarity.
12. **Same-day** — Speed as differentiator.
13. **Membership** — Skip emergency rates — retain angle.
14. **Comparison chart** — DIY vs pro — education.
15. **FAQ cold open** — Answer the #1 question first.
16. **Social proof count** — Reviews volume.
17. **Guarantee clarity** — What’s covered / not — reduces fear.
18. **Seasonal membership** — Bundle spring/fall.
19. **Missed-call empathy** — “We text back in 60s” — service brands.
20. **Diagnostic first** — Free assessment — tutoring / trades.

Avoid: haram niches, fake urgency, unverifiable income claims.
