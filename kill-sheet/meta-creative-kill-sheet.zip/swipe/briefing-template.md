# Creative briefing template (from ITERATE / KILL rows)

**Account / offer:**  
**Target CPA:**  
**Source row ID:**  
**Decision that triggered brief:** KILL / ITERATE  

## Must keep
- Offer / price / URL  
- Compliance lines  

## Must change
- First 3 seconds / first line hook  
- Visual format (if format lost)  

## Hook candidates (pick 2)
1.  
2.  

## Proof asset needed
Testimonial / demo / checklist / photo  

## Success criteria (48–72h)
CTR ≥ _ · CPA ≤ _ · else iterate again or kill  
