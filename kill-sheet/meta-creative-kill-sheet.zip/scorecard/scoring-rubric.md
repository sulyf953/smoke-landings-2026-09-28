# Scoring rubric (1–5 each)

| Dimension | 1 | 3 | 5 |
|-----------|---|---|---|
| Hook strength | Scroll-past | Clear promise | Pattern interrupt + promise |
| CTR vs median | <50% | ~100% | ≥130% |
| CPA vs target | >1.5× | ~1.0–1.2× | ≤0.85× |
| Frequency health | >3.5 rising CPA | 2.5–3.5 | ≤2.5 stable |
| Freshness | >21d same cut | 8–21d | ≤7d or new edit |

**Average → decision:** ≤2.2 KILL · 2.3–3.4 ITERATE · ≥3.5 KEEP  
Break ties with CPA vs target (worse CPA loses).
