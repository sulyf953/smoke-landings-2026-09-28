# Sources (Scout absorb 2026-09-29)

Primary operator threads (r/FacebookAds) cited in Scout feed — validate live:

- How Do You Know When To Turn Off Ads? — spend×CPA clusters
- Am I killing my ads too early? (£200/day) — 72h noise, trained vs cold pixel
- Ad Performance Drop After Initial Sales — fatigue vs fluctuation
- Meta Ads: identify creative fatigue — relative CTR + freq 2.5–3
- Diagnose creative issues — auction / creative / LP tree
- Adding creatives every 3–4 days kills performance — feeder ~20%
- Campaign learning phase — rotate 2–4; remove losers 3–5d apart
- Scale above €150/day — CTR stable + CVR↓ ≠ always kill
- Scaling Meta Ads playbook — 3×/5×/10× CAC stop rules

External gravity (not guarantees): Motion Creative Benchmarks ~5% winners (2026); fatigue writeups (Atria, etc.).

Full annotated feed: `scout-meta-creative-kill-rules-2026-09-29.md` in this folder.
