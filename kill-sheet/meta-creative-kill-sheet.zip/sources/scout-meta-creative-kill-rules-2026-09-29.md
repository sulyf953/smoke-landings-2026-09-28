# Meta Creative Kill Rules — Offer Lab Feed
**Date:** 2026-09-29 (Europe/London)  
**Product north star (BINDING LOCK):** **Meta Creative Kill Sheet** (pack / Fix Pack)  
**Distribution sibling (not competing brand):** Ads Waste Grader (CSV → paid unlock) — Google Search Terms waste first; Meta kill sheet is the product SKU  
**Source of truth:** `/workspace/strategy/CEO-BINDING-LOCK-2026-09-29.md`  
**Halal:** efficiency tooling only; exclude haram vertical creative packs  

---

## TLDR for Offer Lab (productize this)

Ship a **Kill Sheet Pack** (£79–£199 Fix Pack): one-page pass/fail rules + weekly cadence + Advantage+/ASC notes + diagnosis tree (fatigue vs auction vs offer/LP). Seed with the **CONSENSUS** rules below; footnote **CONTESTED** ranges so buyers don’t rage-quit when their CPA band differs.

**Dist hook:** free “paste 7-day Ads Manager export / screenshot checklist” → paid full Kill Sheet + Sheets scorecard. Cross-link Ads Waste Grader for Google CSV path (same family, different SKU).

---

## Ranked rules Offer Lab can productize (1 = densest WTP / clearest operator language)

| Rank | Rule (plain English) | Consensus? | Suggested Kill Sheet line |
|---|---|---|---|
| 1 | **Spend gate before kill:** pause creative only after **~2–3× target CPA** with **0 conversions** (some say 1–1.5×; others 4×). Never judge on calendar days alone. | **Strong consensus on “spend vs CPA,” contested multiplier** | `IF spend ≥ 2× target CPA AND purchases = 0 → PAUSE` (default); show slider 1.5×–4× |
| 2 | **Don’t kill in first 72h:** ROAS/CPA/CVR unreliable while Meta explores; judge **5–7 day** windows. | **Consensus** | `IF age < 72h → HOLD (ignore ROAS/CPA)` |
| 3 | **Fatigue fingerprint:** CTR **dropping** + frequency rising + CPA rising over **several days**; frequency alone is lagging. Cold prospecting fatigue often cited ~**2.5–3+**. | **Consensus on CTR↓+freq↑; contested absolute freq** | `IF CTR↓ ≥15–20% vs own 7d peak AND freq ≥ 2.5–3 → FLAG fatigue` |
| 4 | **Diagnosis tree before creative blame:** CPM↑ + CTR flat/down → auction; CPM flat + CTR↓ → creative; CTR good + no CV → LP/offer. | **Consensus** | Three-branch tree on sheet page 1 |
| 5 | **Feeder / test campaign:** don’t dump new creatives into winning ASC every 3–4 days; test in ABO feeder (~20% budget), promote winners, retire losers **one at a time** spaced 3–5d. | **Consensus** | Cadence SOP card |
| 6 | **CTR floor as weak-creative early signal:** outbound CTR **<~1%** (some <0.5% after volume) → weak hook; but **CTR alone ≠ kill** (winners can convert at low CTR). | **Contested as kill; consensus as watch** | Watchlist, not auto-kill |
| 7 | **Hook / thumbstop early:** declining 3s views / hook rate often precedes CTR death; jewelry ops cite freq>3 + thumbstop↓. | **Emerging consensus; less quantified on Reddit** | Optional advanced row |
| 8 | **Scale ≠ creative death:** scaling past easy-win pocket (e.g. ~€150/day examples) can drop CVR while CTR stable → audience expansion, not always kill creative. | **Consensus nuance** | “Don’t kill on scale dip alone” box |
| 9 | **Grey zone:** borderline at ~5–10× CAC → hold / +20% budget / iterate concept; don’t binary kill. | **Playbook consensus (one long thread)** | Grey-zone card |
| 10 | **Creative velocity:** stopping new concepts after one winner = fatigue tax; concept > hook > format > pixel tweaks. | **Consensus** | Weekly brief checklist |

---

## Argued rules — quotes + URLs (r/FacebookAds primary)

### A) When to turn off / spend×CPA (CONSENSUS core, CONTESTED multiplier)

**Thread:** [How Do You Know When To Turn Off Ads?](https://www.reddit.com/r/FacebookAds/comments/1rnhcaw/how_do_you_know_when_to_turn_off_ads/)

- Operator cluster A: *“A common rule is letting an ad spend around **1–1.5×** your target CPA before deciding.”*
- Operator cluster B: *“If the ad spends **2–3×** your target CPA with 0 results → pause it… If CTR is below ~1%, it’s often a weak creative. If CTR is good but no conversions, the landing page or offer might be the issue.”*
- Spend-not-days: *“What matters less is the number of days and more the amount spent against your target result.”*

**Thread:** [Am I killing my ads too early? £200/day…](https://www.reddit.com/r/FacebookAds/comments/1s057c0/am_i_killing_my_ads_too_early_200day_and_still/)

- Trained pixel / ASC: *“with a trained pixel (100+ purchases in), **3 days and £50–80 per creative** is enough… with a cold pixel you need **5–7 days** minimum and the **first 48 hours are noise**.”*
- Simple rule cited: *“**3 days and £60–80** spent, no add to cart — kill it. ATC but no purchase — wait until day 5.”*
- Conservative: *“give the creative either **7 days or 4× target CPA**.”*
- Structured kill: *“Pause when it hits **2–3× target CPA with 20+ conversions**, or spends **2× target CPA with zero conversions.** Not before.”* + *“**Ignore in first 72 hours:** ROAS, CPA, CVR.”*

**Thread:** [Ad Performance Drop After Initial Sales](https://www.reddit.com/r/FacebookAds/comments/1shxelr/ad_performance_drop_after_initial_sales_whats/)

- Fatigue vs fluctuation: *“If CTR is dropping steadily and CPA rising over several days, that’s usually fatigue… I usually only kill if it spends **2–3×** my target CPA without results.”*
- Death signals: *“CPM creeping up… CTR drops but spend stays… **Frequency above 3–4** and sales don’t follow.”*
- Early-kill tax: *“Killing too early is one of the most common mistakes, because you restart the learning phase.”*

**Kill Sheet default (Offer Lab):** print **2× CPA / 0 purchases** as default kill; footnote 1.5× (aggressive) and 3–4× (patient/high-AOV).

---

### B) Fatigue metrics (CONSENSUS fingerprint, CONTESTED thresholds)

**Thread:** [Meta Ads: How do you actually identify creative fatigue…](https://www.reddit.com/r/FacebookAds/comments/1qk70et/meta_ads_how_do_you_actually_identify_creative/)

- Relative CTR: *“ctr drops **20 to 30 percent** from its own baseline while cpm and cpa trend up and frequency pushes past **2.5 to 3**… judge on relative change per creative not account wide.”*
- Hook-first: *“watch hook rate more than CTR… **Frequency over 3 with declining thumbstop** is usually my trigger.”*

**Thread:** [Ads Performances getting worst after Mid of Feb](https://www.reddit.com/r/FacebookAds/comments/1rd1pm9/ads_performances_getting_worst_after_mid_of_feb/)

- *“If winning creatives are **3–6 weeks** old… Frequency creeping up while CTR drops is the tell… cold audience frequency above **2.5–3×**.”*
- Heuristic split cited: *“Usually these drops are **60% creative fatigue, 30% audience saturation, 10% platform**.”*

**External corroboration (not Reddit, for sheet appendix):**
- Atria 2026 fatigue table: CTR consistent drop over 7d; freq **2.5–3.0** top-funnel warning — https://www.tryatria.com/blog/meta-creative-fatigue-diagnose-and-fix-2026
- Meta research-shaped decay notes (frequency alone insufficient) — https://adsuploader.com/blog/facebook-ad-fatigue

---

### C) Diagnosis tree: hook vs offer vs LP (CONSENSUS)

**Thread:** [Need a repeatable way to diagnose creative issues…](https://www.reddit.com/r/FacebookAds/comments/1rkowpr/need_a_repeatable_way_to_diagnose_creative_issues/)

- *“CPM rising + CTR flat/down → auction pressure… Don’t touch creative.”*
- *“CPM flat + CTR dropping → creative is fatiguing.”*
- *“Never kill in the first 72 hours.”*
- Test discipline: *“Concept > Hook > Format… One challenger… If it loses at **3× CPA** spend, kill.”*
- Freq nuance: *“if frequency is over **4** and cpc spiked, your creative is dead… if frequency under 2 and cpm jumped, audience too narrow.”*

---

### D) Testing cadence / learning reset (CONSENSUS: feeder campaign)

**Thread:** [Adding new creatives every 3–4 days kills performance](https://www.reddit.com/r/FacebookAds/comments/1qk6pb5/adding_new_creatives_every_34_days_kills/)

- *“I keep a separate testing campaign at like **20% budget** and only move winners over.”*
- *“Dump new creatives [in feeder]… Once a creative proves… move it into the winners campaign.”*

**Thread:** [Campaign learning phase](https://www.reddit.com/r/FacebookAds/comments/1riuaow/campaign_learning_phase/)

- *“rotate creatives in small batches… add **2–4** new variants… Remove losers one at a time, spaced **3–5 days**… always adding before removing.”*

---

### E) Scale wall ≠ always kill creative (CONSENSUS nuance)

**Thread:** [Performance drops every time I scale above €150/day](https://www.reddit.com/r/FacebookAds/comments/1r7501n/performance_drops_every_time_i_scale_above_150day/)

- *“if cpm up + ctr down, it’s auction/creative fatigue. if ctr stable but cvr down, it’s lower intent marginal traffic.”*
- *“Get **4–6 fresh creatives** into rotation before attempting to scale again.”*

**Thread:** [Scaling Meta Ads in 2025 Playbook](https://www.reddit.com/r/FacebookAds/comments/1n6q7lg/scaling_meta_ads_in_2025_playbook/)

- Stop rules cited: *“Kill an ad after spending ~**3× CAC** if below benchmarks… ad set after ~**5× CAC**… close but not good enough cut at ~**10× CAC**.”*
- Warning: *“Over-optimizing for CTR… winning ads with CTR below 1% that scaled profitably.”*
- *“Stop creative testing… Every ad fatigues.”*

---

## Contested vs consensus (one-pager for pack)

| Topic | Consensus | Contested / do not hardcode as single number |
|---|---|---|
| Kill unit | Spend vs target CPA, not “days live” | 1–1.5× vs 2–3× vs 4× CPA |
| Early window | First 48–72h noise | Exact hours before first read |
| Fatigue | CTR↓ + freq↑ + CPA↑ over multi-day | Absolute freq 2.5 vs 3 vs 4; CTR% drop 15 vs 20–30 |
| CTR floor | Useful watch | Auto-kill at 1% (false negatives on converters) |
| Learning | Feeder test campaign | Whether small creative adds reset learning |
| ASC/Advantage+ | Patience + trained pixel changes thresholds | One universal £/creative number |

---

## Google Ads waste sibling (DISTRIBUTION — Ads Waste Grader, not product brand)

Keep in same family / Fix Pack upsell path; do **not** rename Kill Sheet to “Ads Waste.”

| Operator rule (r/PPC) | Evidence URL |
|---|---|
| Sort search terms by cost; mine spend + **0 conversions** for negatives | https://www.reddit.com/r/PPC/comments/1ug5gdv/search_terms_are_disappearing_are_we_losing_too/ |
| Filter: conversions <1 and cost > **5× avg CPA**; n-gram root kills | https://www.reddit.com/r/PPC/comments/1jzvuqz/how_do_you_manage_search_terms_at_scale_in_google/ |
| Weekly automation: **>$50 spend + 0 conv** → negative candidates (human gate) | https://www.reddit.com/r/PPC/comments/1tgwsbi/what_automations_are_you_doing_for_your_ads/ |
| Ambiguous intent always human-gated | https://www.reddit.com/r/PPC/comments/1twjvyo/any_good_ways_to_better_automate_search_term/ |
| Macro proof: median waste **$1,127.54/mo**; 25% accounts **zero negatives**; negatives → ~3× CVR | https://www.wordstream.com/blog/google-ads-performance · https://ppc.land/most-google-ads-accounts-waste-1-127-a-month-study-of-15k-accounts-finds/ |

**Grader → Fix Pack CTA:** “You burned ~$X” + draft negatives → £79 Fix Pack (Google) / Kill Sheet Pack (Meta) as parallel SKUs under Ads Waste family.

---

## Suggested Kill Sheet v1 contents (≤14d)

1. Front: 72h HOLD + 2×CPA/0-purchase KILL + fatigue FLAG (CTR↓15–20% + freq≥2.5).  
2. Diagnosis tree (auction / creative / offer-LP).  
3. Feeder vs Scale campaign cadence (weekly).  
4. Grey-zone card (5–10× CAC).  
5. Advantage+/ASC appendix (trained vs cold pixel).  
6. One worked anonymised example scorecard (Motion-class “~5% winners” narrative OK as gravity cite, not invented client revenue).  
7. Dist: free checklist → Lemon/Stripe £79–199.

**Evidence gravity cite (creative lottery):** Motion Creative Benchmarks 2026 — ~5% winners — https://motionapp.com/library/research/creative-benchmarks-2026/

---

## Handoff blurb (parent → Offer Lab)

> Binding lock #1 PRODUCT = Meta Creative Kill Sheet. Dist = Ads Waste Grader CSV (Google) → paid unlock; Meta Kill Sheet is the pack SKU. Consensus kill = spend≥2× target CPA & 0 purchases; HOLD <72h; fatigue = CTR↓ + freq≥~2.5–3. Contested = exact CPA multiplier (1.5–4×). Feeder campaign cadence is table-stakes. Full quotes+URLs in `/workspace/opportunity-scout/meta-creative-kill-rules-2026-09-29.md`. Build scorecard+PDF+Sheets ≤14d; do not invent case-study revenue.

*Scout notes only; not financial advice. Validate thresholds on buyer’s own CPA before printing as guarantees.*

---

## Acquisition path (CEO MODEL LOCK) — REAL paying buyers

**Who pays:** Meta/Facebook media buyers, DTC operators, freelance media buyers, small PPC agencies (not “interested marketers”).

| Step | Where they hang | First hook |
|---|---|---|
| 1 | r/FacebookAds, r/PPC, Facebook Ads Manager Discord/Slack communities | Free 1-page “72h HOLD / 2×CPA KILL” checklist PDF (no email gate optional) |
| 2 | YouTube Shorts / TikTok “I killed this ad too early” | Loom of scorecard on anonymised Ads export |
| 3 | Motion / Madgicx / Revealbot–adjacent operator Twitter/X | “~5% creatives win (Motion) — here’s the kill sheet” |
| 4 | Agency Slack / WhatsApp buyer groups | White-label PDF for client QBRs (£499+ later) |
| 5 | Dist sibling: Ads Waste Grader CSV (Google) | Same buyers often run Google+Meta → cross-sell Fix Pack |

**First £ path:** Checklist → Lemon/Stripe **Kill Sheet Pack £79–£199** within 14d.  
**Juice → proceeds → next:** Pack cash funds Amazon #2 / GHL #3; do not marry “ads identity.” Flip when ARPU stalls.

---

## STRATEGY MODEL LOCK (required — incomplete without all four)

| Field | Value |
|---|---|
| **1. Buyer** | Meta media buyers / DTC operators / freelance FB Ads managers / small agencies already spending on Meta (paying for creatives+media, not browsers). |
| **2. Where they hang** | r/FacebookAds, r/PPC, Ads Manager operator Discords, Motion/Madgicx-adjacent X, agency buyer WhatsApp/Slack. |
| **3. First acquisition hook** | Free 1-page “72h HOLD / 2×CPA KILL / fatigue FLAG” checklist → Loom scorecard → paid **Kill Sheet Pack £79–£199**. Dist sibling: Ads Waste Grader CSV for Google cross-sell. |
| **4. Kill-if-no-paid** | **No paid Kill Sheet or Fix Pack sale within 14 days** of public checklist+grader live → kill SKU or pivot angle (do not keep “building identity”). |

**Portfolio:** Juice pack cash → proceeds to Amazon #2 / GHL #3. Do not marry ads identity.
