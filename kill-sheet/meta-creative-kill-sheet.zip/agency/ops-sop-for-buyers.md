# Agency ops SOP — running Kill Sheet across accounts

## Cadence
- **Monday kill board (45–60 min per account cluster):** Export creatives → scorecard → pause KILLs → Slack client a 5-line summary only if CPA moved >15%.
- **Wednesday production:** 2 hooks per ITERATE row; never more than 4 net-new creatives/account/week unless spend >£/$3k/week.
- **Friday gate:** WATCH rows that crossed Gate 0 must leave WATCH.

## Roles
| Role | Owns |
|------|------|
| Media buyer | Scorecard decisions, pauses, Advantage+ seeds |
| Creative brief | Hook lines from swipe + ITERATE notes |
| Account lead | Target CPA truth, median CTR calc |

## QA before client reporting
1. Every KILL cites a rule ID (`48h-#1`, etc.).
2. No KEEP with CPA > target unless written exception (brand/lift study).
3. Advantage+ checklist attached when recommending scale.

## Escalation
If an account has **>40% of spend** on creatives that would KILL under 48h rules, stop net-new testing and clear zombies first — testing on a dirty account lies.
