# Client one-pager (paste after Monday kill board)

**Account:** _  
**Week:** _  
**Target CPA:** _  
**Median CTR (14d):** _

## Killed (paused)
| Creative | Spend | CTR | CPA | Rule |
|----------|-------|-----|-----|------|
|  |  |  |  |  |

## Iterating
| Creative | Why iterate | Next hook |
|----------|-------------|-----------|
|  |  |  |

## Keeping / scaling
| Creative | CPA vs target | Next step |
|----------|---------------|-----------|
|  |  |  |

## Ask / blocker
_
