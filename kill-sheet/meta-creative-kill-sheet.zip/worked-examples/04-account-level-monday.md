# Worked example 4 — Full Monday board (composite account)

Assume five creatives (see `scorecard/worked-examples-combined.csv`).

| ID | Decision | Action today |
|----|----------|--------------|
| HVAC-UGC-01 | KILL | Pause; brief demo hook |
| TUT-STAT-04 | ITERATE | New predicted-grade hook |
| B2B-VID-12 | KEEP | +25% budget; A+ seed |
| HVAC-CAR-02 | ITERATE | UGC card 1 |
| B2B-STAT-03 | WATCH | Wait for 3k impr |

**Spend freed from kills:** £78.40 trailing + whatever daily residual.  
**New tests queued:** 2 (HVAC demo, tutoring hook).  
**Advantage+:** only after B2B-VID-12 has two companion creatives (checklist).

This is what “sellable” looks like — a buyer can run the same board tomorrow without you on a call.
