# Worked example 2 — Tutoring static → ITERATE

**Account:** Online GCSE maths tutoring. Target CPA £38. Median CTR ~0.94%.

**Creative:** Results proof static (“Grade 4→7”). CTR fine. CPA £41.40 (1.09×). Frequency 2.9.

**Why not KILL:** Fails no primary kill trigger. Inside iterate band.

**Action:** New hook line: “Predicted grade in 6 weeks — free diagnostic.” Same offer URL. Duplicate ad, pause old after 48h if new beats CPA.

**Buyer argument:** “It’s only slightly over target.” Answer: slight over + rising freq = death by a thousand impressions. Iterate now while CTR still healthy.
