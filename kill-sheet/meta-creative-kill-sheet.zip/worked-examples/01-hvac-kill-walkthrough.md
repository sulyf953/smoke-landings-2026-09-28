# Worked example 1 — HVAC UGC → KILL

**Account:** Local HVAC (leads). Target CPA £35. Account median link CTR 0.95%.

**Creative:** “AC Tune-Up UGC A” — phone selfie, weak opening (“Hey guys so…”), offer buried at 12s.

| Metric | Value | Rule |
|--------|-------|------|
| Spend / Impr | £78.40 / 12.4k | Gate 0 cleared |
| CTR | 0.33% | <0.60% and <50% of median → kill #1 |
| CPA | £78.40 | 2.2× target → kill #2 |

**Action:** Pause within hour. Do **not** “refresh” the same cut. Ship ITERATE: demo of thermostat + price of tune-up in first 3s (see swipe seasonal angles).

**Buyer mistake to avoid:** Leaving it on because “UGC usually works.” Numbers say no.
