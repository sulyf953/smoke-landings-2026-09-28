# Walkthrough — HVAC-UGC-01 KILL (full narrative)

**Context:** Local HVAC, target CPA £55 (booked estimate call), Feed prospecting, 14d median CTR 0.95%.

**Raw row:** Spend £78.40 · Impr 12,400 · Clicks 41 · CTR 0.33% · Results 1 · CPA £78.40 · Freq 1.2

**Gate 0:** Impr 12.4k ≥ 3k, spend £78 ≥ £20 → eligible.

**48h-#1:** CTR 0.33% < 0.60% and < 0.7×0.95%=0.665% → fire.

**48h-#2:** CPA 78.40 / 55 = 1.43× — alone not ≥2×, but #1 already sufficient.

**Decision:** KILL. Pause today. Do not “give it another day.”

**Brief:** Demo hook — tech on ladder / before-after thermostat, first line “Same-day AC repair under £X call-out” (local compliance). Success: CTR ≥0.80%, CPA ≤£55 in 72h or iterate once then kill.

**Client line:** “Paused one UGC that spent £78 for a weak CTR; replacing with demo proof.”
