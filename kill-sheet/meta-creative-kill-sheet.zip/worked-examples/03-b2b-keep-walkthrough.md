# Worked example 3 — B2B SaaS demo → KEEP / SCALE

**Account:** B2B ops tool. Target CPA £40. Creative: screen demo + time-saved hook.

| Metric | Value |
|--------|-------|
| CPA | £28.50 (0.71× target) for 6 days |
| CTR | 1.19% (125% of median) |
| Frequency | 1.9 |

**Action:** KEEP. +25% budget. Seed into Advantage+ with **two more distinct** creatives (checklist says ≥3). Do not edit this ad’s creative in place.

**Buyer argument:** “Advantage+ will replace it anyway.” Answer: Advantage+ still needs strong seeds; feeding it kills wastes learning.
