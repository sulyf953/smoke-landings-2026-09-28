# How to fill the scorecard

1. Set `target_CPA` from client/finance — not from vibes.
2. Compute 14-day median CTR for the same objective.
3. One row per creative (ad), not per ad set.
4. Fill scores 1–5 using rubric; compute avg.
5. Write `rule_fired` (e.g. `48h-#1`) so teammates can audit.
6. Export kills list to your team chat Mondays.
