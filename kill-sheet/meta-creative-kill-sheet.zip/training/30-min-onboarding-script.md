# 30-minute onboarding script (for you or a junior buyer)

## Minute 0–5 — Setup
Open Ads Manager. Filter last 7 days. Add columns: Impressions, Spend, CTR (link), CPC, CPA or Cost per result, Frequency. Export creatives that cleared Gate 0 OR sort by spend desc and take top 15.

## Minute 5–10 — Medians & target
Write target CPA at top of scorecard. Compute median CTR across those rows (spreadsheet MEDIAN). If you only have account average, note it as weaker.

## Minute 10–20 — Score
Fill one row per creative. Apply 48h rules. Tag rule_fired. Don’t debate yet — finish the board.

## Minute 20–25 — Act
Pause all KILL. Duplicate ITERATE with new hook briefs. Leave WATCH alone.

## Minute 25–30 — Plan
Fill next two planner rows. Paste client one-pager if agency.

## Exit criteria
- ≥1 pause if any dog cleared Gate 0
- Scorecard saved in account folder
- Calendar block for next Monday

## Common failure in onboarding
Spending 25 minutes polishing creative opinions. The product is the rules — trust them for a week, then tune thresholds with data.
