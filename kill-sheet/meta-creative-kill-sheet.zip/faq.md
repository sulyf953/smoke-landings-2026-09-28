# FAQ

**Q: Can I use this for Google Demand Gen / YouTube?**  
A: Thresholds differ; CTR floors aren’t portable. Use decision tree logic + your own median; don’t paste 0.60% Feed CTR onto YouTube.

**Q: What if my median CTR is already terrible?**  
A: Fix measurement and offer first. Kill Sheet on a broken funnel just pauses everything. Pre-flight checklist matters.

**Q: Do I need Ads Manager API?**  
A: No. CSV/export paste into the scorecard is enough.

**Q: Is this financial advice?**  
A: No. Operational template for media buying discipline.

**Q: Halal?**  
A: Yes as efficiency tooling; don’t use examples in haram niches.
